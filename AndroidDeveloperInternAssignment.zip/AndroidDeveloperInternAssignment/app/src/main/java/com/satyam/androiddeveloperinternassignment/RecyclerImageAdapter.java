package com.satyam.androiddeveloperinternassignment;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerImageAdapter extends RecyclerView.Adapter<RecyclerImageAdapter.ImageHolder> {

    Context context2;
       ArrayList<ImageModel>uriArrayList;

     RecyclerImageAdapter(Context context2,ArrayList<ImageModel> uriArrayList) {
         this.context2=context2;
        this.uriArrayList = uriArrayList;
    }



    @NonNull
    @Override
    public ImageHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context2).inflate(R.layout.layout_image, parent, false);
        ImageHolder imageHolder = new ImageHolder(view);
        return imageHolder;




    }

    @Override
    public void onBindViewHolder(@NonNull ImageHolder holder, int position) {

        holder.galImage.setImageURI(uriArrayList.get(position).image);


    }

    @Override
    public int getItemCount() {
        return uriArrayList.size();
    }

    public class ImageHolder extends RecyclerView.ViewHolder{

        ImageView galImage;
        public ImageHolder(@NonNull View itemView) {
            super(itemView);

            galImage = itemView.findViewById(R.id.galImage);

            //image

        }
    }

}