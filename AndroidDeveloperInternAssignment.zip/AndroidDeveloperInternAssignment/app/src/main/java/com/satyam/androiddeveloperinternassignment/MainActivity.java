package com.satyam.androiddeveloperinternassignment;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.satyam.androiddeveloperinternassignment.databinding.ActivityMainBinding;
import com.satyam.androiddeveloperinternassignment.databinding.DialogBoxBinding;
import com.satyam.androiddeveloperinternassignment.databinding.LayoutTitleImageBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerTiteImageAdaptor adaptor;

    //image
    ArrayList<ImageModel> uriArrayList = new ArrayList<>();
    RecyclerImageAdapter imageAdapter;
    RecyclerView imgRecyclerviewGal;
    //  ImageView galImage;
    //   Button galImgOk;


    ArrayList<TitleImageModel> arrayList = new ArrayList<>();
    ActivityMainBinding binding;
    DialogBoxBinding binding2;
    private int GalleryReqCode = 1;
    Uri u;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding2 = DialogBoxBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        imgRecyclerviewGal = findViewById(R.id.imgRecyclerviewGal);


        binding.btnOpenDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.dialog_box);

                EditText edtTitle = dialog.findViewById(R.id.edtTitle);

                Button btnOk = dialog.findViewById(R.id.btnOk);


                btnOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String title = "";

                        if (!edtTitle.getText().toString().equals("")) {

                            title = edtTitle.getText().toString();


                        }

                        arrayList.add(new TitleImageModel(title));

                        adaptor.notifyItemInserted(arrayList.size() - 1);

                        recyclerView.scrollToPosition(arrayList.size() - 1);

                        dialog.dismiss();


                    }
                });
                Button btnCancel = dialog.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                dialog.show();


            }
        });


        adaptor = new RecyclerTiteImageAdaptor(this, arrayList);
        recyclerView.setAdapter(adaptor);


    }

    public void Uri() {

        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(Intent.createChooser(intent, "Select Images"), 1);


    }





    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            if (requestCode== GalleryReqCode){


               u=(data.getData());

            }
        }
    }



}