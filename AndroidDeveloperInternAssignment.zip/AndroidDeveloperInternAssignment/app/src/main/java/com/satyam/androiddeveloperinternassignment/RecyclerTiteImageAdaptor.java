package com.satyam.androiddeveloperinternassignment;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerTiteImageAdaptor extends RecyclerView.Adapter<RecyclerTiteImageAdaptor.ViewHolder> {

    //image
    RecyclerImageAdapter imageAdapter;
    RecyclerView imgRecyclerviewGal;

    ArrayList<ImageModel> uriArrayList;

    Context context;
    ArrayList<TitleImageModel> arrayList;




    RecyclerTiteImageAdaptor(Context context, ArrayList<TitleImageModel> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        this.uriArrayList = new ArrayList<>();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout_title_image, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textView.setText(arrayList.get(position).title);

        //image
        holder.galImgOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MainActivity m=new MainActivity();
               m.Uri();
               // uriArrayList.add(new ImageModel());
                imageAdapter.notifyItemInserted(uriArrayList.size() - 1);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView textView,exp;
        Button galImgOk;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.textView);
            galImgOk = itemView.findViewById(R.id.galImgOk);
            imgRecyclerviewGal = itemView.findViewById(R.id.imgRecyclerviewGal);

            imgRecyclerviewGal.setLayoutManager(new LinearLayoutManager(context));
            imageAdapter = new RecyclerImageAdapter(context, uriArrayList);
            imgRecyclerviewGal.setAdapter(imageAdapter);

        }

    }

}


