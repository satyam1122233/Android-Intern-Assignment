package com.satyam.androiddeveloperinternassignment;

import android.net.Uri;

public class ImageModel {
    public Uri image;

    public ImageModel(Uri image) {
        this.image = image;
    }

    // You can add additional methods or properties as per your requirement


}
