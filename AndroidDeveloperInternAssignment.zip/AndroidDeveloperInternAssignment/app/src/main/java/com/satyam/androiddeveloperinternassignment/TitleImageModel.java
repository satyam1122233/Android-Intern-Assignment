package com.satyam.androiddeveloperinternassignment;

import android.media.Image;

public class TitleImageModel {

    String title;
   // int img;



    public TitleImageModel(String title){
        this.title=title;
       // this.img=img;

    }
}
